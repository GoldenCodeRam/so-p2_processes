package main

import (
	"github.com/goldencoderam/so-p2_processes/src/controller"
)

func main() {
    controller.GetMainControllerInstance()
    controller.GetViewControllerInstance()
}

